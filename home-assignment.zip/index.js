const express = require('express');
const mq = require('./src/mq');
const cors=require("cors");
const app = express();
const Ads = require("./Models/Ads");
app.use(cors());
app.use(express.json());

require("./Startup/db")();


app.get('/ads', async (req, res) => {
  let params={
    lat:(req.query.lat)*1,
    long :(req.query.long)*1,
    tags:req.query.tags,
    browsers:req.query.browsers,
    operatingSystems:req.query.operatingSystems
  };
  const ads = await Ads.find({}).lean();
  const result = await filterAds(ads,params);
  return res.send({result:result});
});
app.get('/ads/best', async (req, res) => {
  // TODO: COMPLETE LOGIC.
  return res.send('One ad');
});

mq.subscribe('create-ad', (newAd, ack, nack) => {
  // TODO: COMPLETE LOGIC.  
  ack();
});

async function filterAds(ads,params){
  //console.log(ads.length);
  //console.log(params)
  let tempRes=[];
  ads.forEach(ad => {
    let loc=ad.targeting.location;
    let os =ad.targeting.operatingSystems;
    let browsers = ad.targeting.browsers;
    let dist = Math.sqrt((params.lat-loc.lat)*(params.lat-loc.lat) + (params.long-loc.long)*(params.long-loc.long));
    if( dist<=loc.radius){
      let ok=true;
      
       if(params.operatingSystems){
         if(!os.includes(params.operatingSystems)) ok=false;
       }
       if(params.browsers){
        if(!browsers.includes(params.browsers)) ok=false;
      }
      if(ok) tempRes.push(ad);
    }
  });
  ads=tempRes;
  ads = getSortedResult(ads,params);
  return ads;
}

async function getSortedResult(ads,params){
  for(let k=0;k< ads.length;k++){
      let count=0;
      console.log("*************************")
      //console.log(ads[k])
      let tags = ads[k].targeting.tags;
      console.log(tags)
      for(var i=0;i<params.tags.length;i++){
        console.log(params.tags[i]);
        if(tags.includes(params.tags[i])) count++
      }
      ads[k].priority=count;
      console.log("C:"+count);
    }
  ads.sort((a, b) => (a.priority > b.priority) ? -1 : 1);
  for(let i=0;i<ads.length;i++)
    delete ads[i].priority
  return ads;
}



app.listen(3333, () => console.log('Listening...'));
