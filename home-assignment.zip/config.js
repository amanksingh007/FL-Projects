const config={
    DBURL:"mongodb+srv://razorPay:2Y6izO9BSj6ZtOh7@parvaluemongo.qjnom.mongodb.net/Ads?retryWrites=true&w=majority"
}
module.exports=config;