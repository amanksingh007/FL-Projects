module.exports = {
  publish(message) {
    // Empty - no need to implement.
  },

  subscribe(event, callback) {
    // Empty - No need to implement.
  }
};