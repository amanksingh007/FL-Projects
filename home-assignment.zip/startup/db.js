const config=require("../config");
const mongoose=require("mongoose");
//const data=require("../SampleAds.json");

module.exports=function (){
    const options={
        useUnifiedTopology: true,
        useNewUrlParser: true
    }
    console.log("here")
    mongoose.connect(config.DBURL,options,(err)=>{
        if(err){
            console.log("Connection to Database Failed");
            process.exit();
        }
        console.log("************   DB connection Succeeds  **************");
        const Ads = require("../Models/Ads");
    });
}

