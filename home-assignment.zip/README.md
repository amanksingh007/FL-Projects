# Apester Home Assignment

### Starting
```
npm install
npm start
```