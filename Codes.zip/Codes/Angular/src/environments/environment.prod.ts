export const environment = {
  production: true,
  serviceUrl: 'http://localhost:6000',
};
