import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  constructor(private authService: AuthService, private router: Router) {}
  profile: any;
  ngOnInit(): void {
    this.authService.getProfile().subscribe(
      (res) => {
        this.profile = res.res;
        //console.log(this.profile);
      },
      (err: HttpErrorResponse) => {
        alert('Login failed. Login again');
        this.authService.logout();
        this.router.navigateByUrl('/login');
      }
    );
  }

  logout() {
    this.authService.logout();
    this.router.navigateByUrl('/login');
  }
}
