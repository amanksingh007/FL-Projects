import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  roles = [];
  departments = [];
  constructor(private authService: AuthService, private Router: Router) {}

  ngOnInit(): void {
    this.authService.getRoles().subscribe(
      (res) => {
        this.roles = res.res;
      },
      (err: HttpErrorResponse) => {
        alert('Request failed');
      }
    );

    this.authService.getDepartments().subscribe(
      (res) => {
        this.departments = res.res;
      },
      (err: HttpErrorResponse) => {
        alert('Request failed');
      }
    );
  }
  register(data) {
    if (!data.role || !data.email || !data.password || !data.department) {
      alert('All fields are required');
      return;
    } else
      this.authService.register(data).subscribe(
        (res) => {
          alert('Registration Successfull. Login');
          this.Router.navigateByUrl('/login');
        },
        (err: HttpErrorResponse) => {
          alert(err.error.res);
        }
      );
  }
}
