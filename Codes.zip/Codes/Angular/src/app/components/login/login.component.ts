import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  roles = [];
  departments = [];
  show: boolean = false;
  siteKey = '6LenIWwaAAAAAKaG0INQ6R_wTsrp6u8KcwnAR7xR';
  theme = 'dark';
  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.authService.getRoles().subscribe(
      (res) => {
        this.roles = res.res;
      },
      (err: HttpErrorResponse) => {
        alert('Request failed');
      }
    );

    this.authService.getDepartments().subscribe(
      (res) => {
        this.departments = res.res;
      },
      (err: HttpErrorResponse) => {
        alert('Request failed');
      }
    );
  }
  login(data) {
    if (!data.email || !data.password || !data.department || !data.captcha) {
      alert('All fields are required');
      return;
    } else
      this.authService.login(data).subscribe(
        (res) => {
          this.authService.saveAuthToken(res.res);
          //console.log(res);
          this.router.navigateByUrl('/profile');
        },
        (err: HttpErrorResponse) => {
          alert(err.error.res);
        }
      );
  }
  selected() {
    //console.log('Her');
    this.show = true;
  }
}
