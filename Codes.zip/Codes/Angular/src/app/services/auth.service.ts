import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  serviceUrl = environment.serviceUrl;
  constructor(private http: HttpClient) {}

  login(data) {
    console.log(data);
    const API = this.serviceUrl + '/login';
    return this.http.post<any>(API, data);
  }
  register(data) {
    const API = this.serviceUrl + '/register';
    return this.http.post(API, data);
  }
  getRoles() {
    const API = this.serviceUrl + '/roles';
    return this.http.get<any>(API);
  }
  getDepartments() {
    const API = this.serviceUrl + '/departments';
    return this.http.get<any>(API);
  }
  getProfile() {
    const API = this.serviceUrl + '/profile';
    const token = this.getAuthToken();
    return this.http.get<any>(API, {
      headers: new HttpHeaders().set('x-auth-token', token),
    });
  }

  loggedIn() {
    const token = this.getAuthToken();
    if (token) return true;
    else return false;
  }
  getAuthToken() {
    return localStorage.getItem('appToken');
  }
  saveAuthToken(token) {
    localStorage.setItem('appToken', token);
    return;
  }
  logout() {
    localStorage.removeItem('appToken');
  }
  resetPassword(data) {
    const API = this.serviceUrl + '/resetPassword';
    return this.http.post(API, data);
  }
}
