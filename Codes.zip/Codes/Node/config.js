const config = {
  DB_USER: "pmybicvy",
  DB_HOST: "john.db.elephantsql.com",
  DB_PASSWORD: "CCljFRiYoqaO-mQTko2aOVNze2kXd7wi",
  DB_DATABASE: "pmybicvy",
  DB_POST: "5432",
  DB_CONSTR:
    "postgres://pmybicvy:CCljFRiYoqaO-mQTko2aOVNze2kXd7wi@john.db.elephantsql.com:5432/pmybicvy",
  JWT_SECRET_KEY:
    "Xyw23TerThki!&##0Xkqvchlijxuieg865472chc78hhjhsjy3748hbfjusut7oLM",
};

module.exports = config;
