const mongoose=require("mongoose");
const data=require("./SampleAds.json");
const AdsSchema = new mongoose.Schema();
//console.log(data);
AdsSchema.add({
    id:{
        type:String,
        required:true,
    },
    description:{
        type:String,
        required:true,
    },
    imageUrl:{
        type:String,
        required:true,
    },
    targeting:{
        type:{ location:{lat:Number,long:Number,radius:Number},
        operatingSystems:[String],
        browsers:[String],
        tags:[String]
        },
      default:{}
    }
});

const Ads = mongoose.model("Ads",AdsSchema);

// Ads.insertMany(data).then(function(){ 
//     console.log("Data inserted")   
// }).catch(function(error){ 
//     console.log(error)      
// });

module.exports=Ads;
