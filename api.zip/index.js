const express = require('express');
const mq = require('./src/mq');
const cors=require("cors");
const handlers= require("./services/handlers");
const app = express();
const Ads = require("./Models/Ads");
app.use(cors());
app.use(express.json());

require("./Startup/db")();


app.get('/ads', async (req, res) => {
  try{
    if(!req.query.lat || !req.query.long)
      return res.status(400).send({result:"User location is required."})
    let params={
      lat:(req.query.lat)*1,
      long :(req.query.long)*1,
      tags:req.query.tags,
      browsers:req.query.browsers,
      operatingSystems:req.query.operatingSystems
    };
    const ads = await Ads.find({}).lean();
    const result = await handlers.filterAds(ads,params);
    return res.status(200).send({result:result});
  }catch(ex){
    console.log(ex);
    return res.status(500).send({result:"Server error occured"});
  }
});
app.get('/ads/best', async (req, res) => {
  try{
    let params={
      lat:(req.query.lat)*1,
      long :(req.query.long)*1,
      tags:req.query.tags,
      browsers:req.query.browsers,
      operatingSystems:req.query.operatingSystems
    };
    const ads = await Ads.find({}).lean();
    const result = await handlers.filterAds(ads,params);
    return res.send({result:result[0]});
  }catch(ex){
  console.log(ex);
  return res.status(500).send({result:"Server error occured"});
}
});

mq.subscribe('create-ad', (newAd, ack, nack) => {
  // TODO: COMPLETE LOGIC.  
  ack();
});




app.listen(3333, () => console.log('Listening...'));
