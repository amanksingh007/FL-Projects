const config={
    DBURL:""
}
module.exports=config;